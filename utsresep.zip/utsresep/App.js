import { StatusBar } from "expo-status-bar";
import React from "react";
import { Text, View, Image, Button, StyleSheet, TouchableOpacity } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

// import Head from "./componen/Head";
import Coba from "./componen/Coba";
import Post from "./componen/Post";
import Home from "./screen/Home";
import Resep from "./screen/Resep";
import ResepMasakan from "./screen/ResepMasakan";

// my_pallet : #FEB000 kuning (warna dasar)
//           : #F7F6F2 abu-abu

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const CustomTabBarButton = ({children, onPress}) => (
  <TouchableOpacity
    style={{
      top: -30,
      alignItems : 'center',
      justifyContent : 'center',
      ...styles.shadow
    }}
    onPress={onPress}
  >
    <View style={{
      width: 70,       
      height: 70,
      borderRadius: 40,
      backgroundColor : '#FEB000'
    }}>
      {children}
    </View>
  </TouchableOpacity>
);


function LogoTitle() {
  return (
    <Image
      style={{ width: 40, height: 40 }}
      source={require('../utsresep/assets/user.png')}
    />
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="auto" backgroundColor="#FEB000" />
      <Stack.Navigator>
      <Stack.Screen name="Home" component={Tab1}  options={{headerTitle: (props) => <LogoTitle {...props} />, headerRight: () => (
      <Button onPress={() => alert('Belum Ada Fungsi, Ini ada biar UI/UX nya bagus')} title="Info" color="#FEB000"/>
            ),
          }}
        />
        {/* <Stack.Screen name="Head" component={Head} /> */}
        {/* <Stack.Screen name="Home" component={Home} /> */}
        <Stack.Screen name="Resep" component={Resep} />
        <Stack.Screen name="ResepMasakan" component={ResepMasakan} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export function Tab1() {
  return (

      <Tab.Navigator
        tabBarOptions={{
          showLabel: false,
          style:{
            position : 'absolute',
            bottom : 30,
            left: 20,
            right: 20,
            elevation:0,
            backgroundColor: '#ffffff', 
            borderRadius: 15,
            height:100,
            ...styles.shadow

          }
        }}
      >
        <Tab.Screen 
          name="Home" 
          component={Home} 
          options={{
            headerShown:false, 
            tabBarIcon: ({focused}) => ( 
              <View style={{ alignItems: 'center', justifyContent:'center', top: 1 }} >
                <Image 
                  source={require('../utsresep/assets/home.png')}
                  resizeMode='contain' 
                  style={{
                    width : 20,
                    height: 20,
                    tintColor: focused ? '#FEB000' :'#748c94',
                  }} 
                />
                <Text 
                  style={{ color: focused ? '#FEB000' :'#748c94', fontSize:13}}> 
                  HOME 
                </Text>
              </View> 
            ),
          }}
        />
        <Tab.Screen name="Post" component={Post} 
          options={{ 
            headerShown:false,
            tabBarIcon:({focused}) =>( 
              <Image 
                source={ require ('../utsresep/assets/ger.png')} 
                resizeMode='contain'
                style={{
                  width: 35,
                  height: 35,
                  tintColor: '#fff'
                }}
              /> 
            ),
            tabBarButton: (props) => (
              <CustomTabBarButton {...props} />
            )  
          }}
        />
        <Tab.Screen 
          name="Coba" 
          component={Coba} 
          options={{
            headerShown:false, 
            tabBarIcon: ({focused}) => ( 
              <View style={{ alignItems: 'center', justifyContent:'center', top: 1 }} >
                <Image 
                  source={require('../utsresep/assets/org.png')}
                  resizeMode='contain' 
                  style={{
                    width : 20,
                    height: 20,
                    tintColor: focused ? '#FEB000' :'#748c94',
                  }} 
                />
                <Text 
                  style={{ color: focused ? '#FEB000' :'#748c94', fontSize:13}}> 
                  PROFIL
                </Text>
              </View> 
            ),
          }}
        />
      </Tab.Navigator>
  
  );
}

const styles = StyleSheet.create({
  shadow: {
    shadowColor: '#7f5df0',
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowOpacity: 0.25,
    shadowRadius : 3.5,
    elevation:5
  }
})
