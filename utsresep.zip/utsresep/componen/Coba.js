import React from "react";
import {View, StyleSheet, Text, Image} from 'react-native';
import Logo from "./Logo";

const Coba = () => {
  return (
    <View style={styles.screen}>
      <View>
        <Image source={require('../assets/user100.png')} style={{ width: 115, height:115, resizeMode:'cover'}}/>
      </View>
      <View> 
        <Text style={styles.header}> Iqbal Tawwaqal </Text> 
      </View>
      <View>
        <Text style={styles.teks}> Freelance | Motion Graphic </Text>
      </View>
      <View style={styles.container}>
        <Image source={require('../assets/ig_kuning.png')} style={{ width: 20, height:20,}}/>
        <Text style={{fontSize:18}} > @taqqi22  </Text>
      </View>
      <View style={styles.container}>
        <Image source={require('../assets/wa_kuning.png')} style={{ width: 20, height:20,}}/>
        <Text style={{fontSize:18}} > +62 877  </Text>
      </View>

      <View style={styles.container}>
        <Logo name="in"/>
        <Logo name="f"/>
        <Logo name="t"/>
      </View>
      <View>
        <Text style={styles.teksStyle}> Chef is a person who work in the restaurant and have a duty to cook a meal for the customer. they usually wear a white cloth and a chef hat on their head. they must be an expert in cooking skill to become a chef </Text>
      </View>
    </View>

  );
};

const styles = StyleSheet.create({
  screen :{
    flex: 1,
    alignItems: "center",
    paddingTop: 50
  },
  header:{
    fontSize: 40,
    marginVertical: 5,
  },
  teks:{
    fontSize: 20,
    marginVertical: 5,
    textAlign: 'center',
  },
  container:{
    flexDirection: 'row',
    marginVertical: 5,
    paddingTop:10,
  },

  teksStyle:{
    padding:10,
    margin:10,
    marginLeft:10,
    fontSize: 18,
    marginVertical: 5,
    color: '#000000',
    textAlign: 'center'
  },

});

export default Coba;