// import { StatusBar } from "expo-status-bar";
// import React from "react";
// import { View, StyleSheet, TouchableOpacity, Image} from "react-native";

// const Head = () => {
//     return (
//     <View style={styles.header}> 
//         <StatusBar/>
//             <TouchableOpacity onPress={() => {}}>
//                 <Image source={require("../assets/menu.png")} style={{width:20, height:20}}/>
//             </TouchableOpacity>
//             <View>
//                 <View style={styles.iconsView}>
//                     <Image source={require("../assets/org.png")} style={styles.icons}/>
//                     <Image source={require("../assets/down.png")} style={styles.icons}/>
//                 </View>
//             </View>
//     </View>
//     );
// };

// export default Head;

// const styles = StyleSheet.create({
//     header:{
//         backgroundColor: "#000",
//         flexDirection : "row",
//         justifyContent : 'space-between',
//         padding :15,
//     },
//     iconsView:{
//         flexDirection: "row",
//         alignItems :"center",
//         justifyContent:"center",
//     },
//     icons: {
//         width:36,
//         height: 16,
//         resizeMode:"contain",
//     }
// });

// backup data coba
// import React from "react";
// import { StyleSheet, Text, View, Image, Button, ScrollView } from "react-native";

// const Coba = ({navigation}) => {
//   return (
//       <ScrollView style={styles.isi}>
//         <View style={styles.container}> 
//             <Image source={require("../assets/batman.png")} style={{ width: 256, height:256}}/>
//             <Text style={styles.judul}>Iqbal Tawwaqal</Text>
//             <Text> apa aja boleh </Text>

//             <Text> apa aja boleh </Text>
//             <Button style={styles.tombol} title="Resep Masakan" onPress={() => navigation.navigate('Resep')} color="#FEB000" />
//         </View>
//       </ScrollView>
    
//   );
// };

// export default Coba;

// const styles = StyleSheet.create({
//     isi : {
//         backgroundColor: "#F7F6F2",
//         width: "100%"
//     },
//     container :{
//         justifyContent:"center",
//         borderRadius: 10,
//         // alignItems:"center",
//         flex:1,
//         padding: 40,
//         width: "80%"
//     },
//     judul :{
//         fontWeight:"bold",
//         fontSize:23   
//     }
// })

