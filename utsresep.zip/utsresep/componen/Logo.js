import React from "react";
import {View, StyleSheet, Text} from 'react-native';


const Logo = props => {
    return(
        <View style={styles.iconContainer}>
            <Text style={styles.teksStyle}>{props.name}</Text>
        </View>

    )
}

const styles = StyleSheet.create({
    iconContainer: {
        width:50,
        height: 50,
        borderRadius: 5,
        borderColor:'#FEB000',
        overflow: "hidden",
        borderWidth:2,
        marginHorizontal: 10
    },
    teksStyle:{
        fontSize: 24,
        color: '#FEB000',
        textAlign: 'center'
    }


});

export default Logo;