import React from "react";
import { Text, View, Image,} from "react-native";

const Post = () => {
  return (
      <View> 
          <View style={{alignItems:'center', paddingTop:'70%'}}> 
            <Image source={require('../assets/post.png')} style={{ width: 100, height:100, alignItems:'center'}}/>
          </View>
          <View>
            <Text style={{alignItems:'center', fontSize:20, color:'#FEB000', paddingLeft:125, paddingTop:10}}>Post Your Cook</Text>
          </View>
      </View>

    
  );
};

export default Post;