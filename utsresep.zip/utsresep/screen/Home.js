import React from "react";
import { StyleSheet, Text, View, Image, Button, ScrollView } from "react-native";

const Home = ({navigation}) => {
  return (
      
        <ScrollView style={styles.isi}
            scrollEventThrottle={16}
        >
            <View style={{ flex: 1, backgroundColor: '#F7F6F2', paddingTop: 20 }}>
                <Text style={{ fontSize: 24, fontWeight: '700', paddingHorizontal: 20 }}>
                    These Are Some Of Our Food Recommendations...
                </Text>

                <View style={{ height: 130, marginTop: 20 }}>
                    <ScrollView
                        horizontal={true}
                        showsHorizontalScrollIndicator={false}
                    >
                        <Image source={require('../assets/makan.jpg')} style={{ width: 256, height:130, marginLeft:7, marginRight:7, borderRadius:5}}
                        />
                        <Image source={require('../assets/makan1.jpg')} style={{ width: 256, height:130, marginLeft:7, marginRight:7, borderRadius:5}}
                        />
                        <Image source={require('../assets/makan2.jpg')} style={{ width: 256, height:130, marginLeft:7, marginRight:7, borderRadius:5}}
                        />
                    </ScrollView>
                </View>
                <View style={{ marginTop: 40, paddingHorizontal: 20 }}>
                    <Text style={{ fontSize: 24, fontWeight: '700' }}>
                        Masakan Luar
                    </Text>
                    <Text style={{ fontWeight: '100', marginTop: 10 }}>
                        Nasi goreng merupakan salah satu makanan khas yang Sering ditemukan di berbagai daerah di Indonesia. Disajikan dalam berbagai varian rasa yang dapat disesuaikan dengan keinginan para konsumen. Aroma khas dari bumbu nasi goreng akan membuat siapapun yang menciumnya merasa kelaparan.
                    </Text>

                    <Text style={{ fontWeight: '100', marginTop: 10 }}>
                        Foto from : Ella Olsson
                    </Text>

                    <View style={{ width: - 40, height: 200, marginTop: 20 }}>
                        <Image
                            style={{ flex: 1, height: null, width: null, resizeMode: 'cover', borderRadius: 5, borderWidth: 1, borderColor: '#dddddd' }}
                            source={require('../assets/makan.jpg')}
                        />
                    </View>
                </View>

                <View style={{ marginTop: 40, paddingHorizontal: 20 }}>
                    <Text style={{ fontSize: 24, fontWeight: '700' }}>
                        Masakan Luar Ke-1
                    </Text>
                    <Text style={{ fontWeight: '100', marginTop: 10 }}>
                        Nasi goreng merupakan salah satu makanan khas yang Sering ditemukan di berbagai daerah di Indonesia. Disajikan dalam berbagai varian rasa yang dapat disesuaikan dengan keinginan para konsumen. Aroma khas dari bumbu nasi goreng akan membuat siapapun yang menciumnya merasa kelaparan.
                    </Text>

                    <Text style={{ fontWeight: '100', marginTop: 10 }}>
                        Foto from : Ella Olsson
                    </Text>
                    <View style={{ width: - 40, height: 200, marginTop: 20 }}>
                        <Image
                            style={{ flex: 1, height: null, width: null, resizeMode: 'cover', borderRadius: 5, borderWidth: 1, borderColor: '#dddddd' }}
                            source={require('../assets/makan1.jpg')}
                        />
                    </View>
                </View>

                <View style={{ marginTop: 40, paddingHorizontal: 20 }}>
                    <Text style={{ fontSize: 24, fontWeight: '700' }}>
                        Masakan Luar Ke-2
                    </Text>
                    <Text style={{ fontWeight: '100', marginTop: 10 }}>
                        Nasi goreng merupakan salah satu makanan khas yang Sering ditemukan di berbagai daerah di Indonesia. Disajikan dalam berbagai varian rasa yang dapat disesuaikan dengan keinginan para konsumen. Aroma khas dari bumbu nasi goreng akan membuat siapapun yang menciumnya merasa kelaparan.
                    </Text>

                    <Text style={{ fontWeight: '100', marginTop: 10 }}>
                        Foto from : Ella Olsson
                    </Text>
                    <View style={{ width: - 40, height: 200, marginTop: 20 }}>
                        <Image
                            style={{ flex: 1, height: null, width: null, resizeMode: 'cover', borderRadius: 5, borderWidth: 1, borderColor: '#dddddd' }}
                            source={require('../assets/makan2.jpg')}
                        />
                    </View>
                </View>

                <View style={styles.container}>
                <Button title="Detail" onPress={() => navigation.navigate("Resep")} color="#FEB000" />
                </View>
                
            </View>
        </ScrollView>

  );
};

export default Home;

const styles = StyleSheet.create({
    isi : {
        backgroundColor: "#F7F6F2",
        width: "100%"
    },
    container :{
        justifyContent: 'flex-end',
        borderRadius: 10,
        marginLeft: 100,
        paddingLeft:100,
        paddingTop: 20,
        paddingBottom: 50,
        width: "70%"
    },
    judul :{
        fontWeight:"bold",
        fontSize:23   
    }
})