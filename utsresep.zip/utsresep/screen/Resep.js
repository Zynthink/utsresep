import React, {useState, useEffect} from "react";
import { StyleSheet, Text, TouchableOpacity, View, FlatList, Image, ActivityIndicator } from "react-native";

const Resep = ({navigation}) => {
    const [ data, setData,] = useState([]);
    const [ isLoading, setLoading,] = useState([])

    const getResepData = async () => {
        try{
            const response = await fetch("https://masak-apa-tomorisakura.vercel.app/api/recipes");
            const json = await response.json();
            setData(json.results);
        } catch (error){
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const renderItem = ({item}) => {
        return (
            <TouchableOpacity
                onPress={() => navigation.navigate('ResepMasakan', {data:item.key})}
                style={styles.container}
            >
                <Image source={{uri : item.thumb}} style={{ width: 256, height:156, borderRadius:10, borderWidth: 2, borderColor: '#fff'}}/>
                <View>
                    <Text style={styles.judulResep}>{item.title}</Text>
                    <View style={{flexDirection:"row"}}>
                        <Image source={require('../assets/cara.png')} style={{ width: 25, height:25,}}/>
                        <Text style={styles.judulisi}>{item.key}</Text>
                    </View>
                    <View style={{flexDirection:"row"}} >
                        <Image source={require('../assets/jam.png')} style={{ width: 25, height:25,}}/>
                        <Text style={styles.judulisi}>{item.times}</Text>
                    </View>
                    <View style={{flexDirection:"row"}}>
                        <Image source={require('../assets/porsi.png')} style={{ width: 25, height:25,}}/>
                        <Text style={styles.judulisi}>{item.portion}</Text>
                    </View>
                    <View style={{flexDirection:"row"}}>
                        <Image source={require('../assets/mudah.png')} style={{ width: 25, height:25, }}/>
                        <Text style={styles.judulisi}>{item.dificulty}</Text>
                    </View>
                </View>
                
                
            </TouchableOpacity>
        );
    };

    useEffect(()=>{
        getResepData();
    }, [])
  return (
      <View>
          {
              isLoading ? (
                  <ActivityIndicator size="large" color="#FEB000" />
              ):(
                    <FlatList
                    data={data}
                    keyExtractor={item => item.key}
                    renderItem={renderItem}
                    />
              )
          }
          
      </View>
  );
};

export default Resep;

const styles = StyleSheet.create({
    container: {
        flex:1,
        alignItems:'center',
        margin:20,
        backgroundColor: '#FEB000',
        paddingTop: 20,
        paddingRight: 20,
        paddingLeft: 20,
        borderRadius:15
    },

    judulResep :{
        fontWeight:'bold',
        fontSize:20,
        marginTop: 10,
        marginBottom:10,
        color: '#ffffff',
    },
    judulisi :{
        flexDirection : "row",
        fontSize:20,
        marginBottom:10,
        color: '#ffffff',
    },
})