import React, {useState, useEffect} from "react";
import { StyleSheet, Text, Image, ActivityIndicator, View, ScrollView } from "react-native";

const ResepMakanan = ({route}) => {

    const [ data, setData,] = useState([]);
    const [ isLoading, setLoading,] = useState([])

    const urldata = "https://masak-apa-tomorisakura.vercel.app/api/recipe/"+route.params.data+"";
    console.log(urldata);

    const getResepMakanan = async () => {
        try{
            const response = await fetch(urldata);
            const json = await response.json();
            setData(json.results);
        } catch (error){
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(()=>{
        getResepMakanan();
    }, [])
    const bahanmakanan = []
    const caramasak = []
    if (!isLoading) {
        for (let index = 0; index < data.ingredient.length; index++) {
            bahanmakanan.push(<Text>{data.ingredient[index]}</Text>);
        }
    
        for (let index = 0; index < data.step.length; index++) {
            caramasak.push(<Text style={{ fontSize: 20, marginBottom: 10 }}>{data.step[index]}</Text>);
        }
    }

    return (
        <ScrollView>
        {
            isLoading ? (
                <ActivityIndicator size="large" color="#FEB000" />
            ):(
                <View>
                    <View style={styles.container}>
                        <View style={{alignItems:'center'}}>
                            <Image source={{uri : data.thumb}} style={{ width: 256, height:156, borderRadius:10, borderWidth: 3, borderColor: '#FEB000',}}/>
                        </View>
                        <Text style={{marginTop:30, marginBottom: 20,}}>{route.params.data}</Text>
                        <Text style={styles.subJudul}> Resep By {data.author.user}</Text>
                        <Text style={styles.judul}>{data.title}</Text>
                        <Text >{data.servings}, {data.dificulty}</Text>
                        <View style={styles.bahan}>
                            {bahanmakanan}
                        </View>
                        <View style={styles.step}>
                            {caramasak}
                        </View>
                    </View> 
                </View>

            )
        }
        
    </ScrollView>
      
    )
  }
  
  export default ResepMakanan;

  const styles = StyleSheet.create({
      container:{
          width: '100%',
          padding : 20,
      },

      judul : {
          fontWeight : "bold",
          fontSize: 32
      },

      subJudul : {
          alignItems:'baseline',
          fontSize : 15,
      },

      bahan: {
        width: '100%',
        backgroundColor: '#FEB000',
        padding: 50,
        marginTop: 10,
        borderRadius: 10,
      },

      step :{
          alignItems:'center',
          fontSize: 10,
          marginTop:15,
          paddingBottom:20,
          
      }
  })